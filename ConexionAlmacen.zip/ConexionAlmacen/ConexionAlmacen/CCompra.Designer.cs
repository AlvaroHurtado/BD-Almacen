﻿namespace ConexionAlmacen
{
    partial class CCompra
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dtgCompra = new DataGridView();
            btnNuevaCompra = new Button();
            btnRegresar = new Button();
            ((System.ComponentModel.ISupportInitialize)dtgCompra).BeginInit();
            SuspendLayout();
            // 
            // dtgCompra
            // 
            dtgCompra.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dtgCompra.Location = new Point(12, 57);
            dtgCompra.Name = "dtgCompra";
            dtgCompra.RowTemplate.Height = 25;
            dtgCompra.Size = new Size(776, 381);
            dtgCompra.TabIndex = 0;
            // 
            // btnNuevaCompra
            // 
            btnNuevaCompra.Location = new Point(12, 12);
            btnNuevaCompra.Name = "btnNuevaCompra";
            btnNuevaCompra.Size = new Size(102, 23);
            btnNuevaCompra.TabIndex = 1;
            btnNuevaCompra.Text = "Nueva Compra";
            btnNuevaCompra.UseVisualStyleBackColor = true;
            btnNuevaCompra.Click += btnNuevaCompra_Click;
            // 
            // btnRegresar
            // 
            btnRegresar.Location = new Point(713, 12);
            btnRegresar.Name = "btnRegresar";
            btnRegresar.Size = new Size(75, 23);
            btnRegresar.TabIndex = 2;
            btnRegresar.Text = "Regresar";
            btnRegresar.UseVisualStyleBackColor = true;
            btnRegresar.Click += btnRegresar_Click;
            // 
            // CCompra
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnRegresar);
            Controls.Add(btnNuevaCompra);
            Controls.Add(dtgCompra);
            Name = "CCompra";
            Text = "CCompra";
            Load += CCompra_Load;
            ((System.ComponentModel.ISupportInitialize)dtgCompra).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dtgCompra;
        private Button btnNuevaCompra;
        private Button btnRegresar;
    }
}