﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConexionAlmacen
{
    public partial class CFrmDepartamentos : Form
    {
        private int? Id;

        public CFrmDepartamentos(int? pId = null)
        {
            InitializeComponent();
            this.Id = pId;
        }

        private void CFrmDepartamentos_Load(object sender, EventArgs e)
        {
            if (Id != null)
            {
                DSAlmacenTableAdapters.DepartamentosTableAdapter ta = new DSAlmacenTableAdapters.DepartamentosTableAdapter();
                DSAlmacen.DepartamentosDataTable dt = ta.ObtenerDepartamento((int)Id);
                DSAlmacen.DepartamentosRow row = (DSAlmacen.DepartamentosRow)dt.Rows[0];
                txtDepartamento.Text = row.nombreDepartamento;
                txtDescripcion.Text = row.descripcionDepartamento;
            }
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            DSAlmacenTableAdapters.DepartamentosTableAdapter ta = new DSAlmacenTableAdapters.DepartamentosTableAdapter();

            if (Id == null)
            {
                ta.AgregarDepartamento(txtDepartamento.Text, txtDescripcion.Text);
            }
            else
            {
                ta.ActualizarDepartamento((int)Id, txtDepartamento.Text, txtDescripcion.Text);
            }
            this.Close();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
