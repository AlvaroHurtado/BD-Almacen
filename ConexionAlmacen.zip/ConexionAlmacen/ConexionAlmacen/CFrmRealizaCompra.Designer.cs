﻿namespace ConexionAlmacen
{
    partial class CFrmRealizaCompra
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dtgRealizaVenta = new DataGridView();
            Descripcion = new DataGridViewTextBoxColumn();
            Precio = new DataGridViewTextBoxColumn();
            Cantidad = new DataGridViewTextBoxColumn();
            Subtotal = new DataGridViewTextBoxColumn();
            Eliminar = new DataGridViewButtonColumn();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txtIdProveedor = new ComboBox();
            txtProducto = new TextBox();
            txtPrecio = new TextBox();
            label4 = new Label();
            txtCantidad = new TextBox();
            btnAgregar = new Button();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            lblTotal = new Label();
            button1 = new Button();
            btnCancelar = new Button();
            ((System.ComponentModel.ISupportInitialize)dtgRealizaVenta).BeginInit();
            SuspendLayout();
            // 
            // dtgRealizaVenta
            // 
            dtgRealizaVenta.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dtgRealizaVenta.Columns.AddRange(new DataGridViewColumn[] { Descripcion, Precio, Cantidad, Subtotal, Eliminar });
            dtgRealizaVenta.Location = new Point(12, 191);
            dtgRealizaVenta.Name = "dtgRealizaVenta";
            dtgRealizaVenta.RowTemplate.Height = 25;
            dtgRealizaVenta.Size = new Size(776, 247);
            dtgRealizaVenta.TabIndex = 0;
            dtgRealizaVenta.CellClick += dtgRealizaVenta_CellClick;
            // 
            // Descripcion
            // 
            Descripcion.HeaderText = "Descripción";
            Descripcion.Name = "Descripcion";
            // 
            // Precio
            // 
            Precio.HeaderText = "Precio";
            Precio.Name = "Precio";
            // 
            // Cantidad
            // 
            Cantidad.HeaderText = "Cantidad";
            Cantidad.Name = "Cantidad";
            // 
            // Subtotal
            // 
            Subtotal.HeaderText = "Subtotal";
            Subtotal.Name = "Subtotal";
            // 
            // Eliminar
            // 
            Eliminar.HeaderText = "Eliminar";
            Eliminar.Name = "Eliminar";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(12, 30);
            label1.Name = "label1";
            label1.Size = new Size(114, 24);
            label1.TabIndex = 1;
            label1.Text = "Proveedor:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(12, 75);
            label2.Name = "label2";
            label2.Size = new Size(100, 24);
            label2.TabIndex = 2;
            label2.Text = "Producto:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(12, 120);
            label3.Name = "label3";
            label3.Size = new Size(77, 24);
            label3.TabIndex = 3;
            label3.Text = "Precio:";
            // 
            // txtIdProveedor
            // 
            txtIdProveedor.FormattingEnabled = true;
            txtIdProveedor.Location = new Point(157, 31);
            txtIdProveedor.Name = "txtIdProveedor";
            txtIdProveedor.Size = new Size(336, 23);
            txtIdProveedor.TabIndex = 4;
            // 
            // txtProducto
            // 
            txtProducto.Location = new Point(157, 75);
            txtProducto.Name = "txtProducto";
            txtProducto.Size = new Size(336, 23);
            txtProducto.TabIndex = 5;
            // 
            // txtPrecio
            // 
            txtPrecio.Location = new Point(157, 120);
            txtPrecio.Name = "txtPrecio";
            txtPrecio.Size = new Size(117, 23);
            txtPrecio.TabIndex = 6;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(293, 119);
            label4.Name = "label4";
            label4.Size = new Size(99, 24);
            label4.TabIndex = 7;
            label4.Text = "Cantidad:";
            // 
            // txtCantidad
            // 
            txtCantidad.Location = new Point(398, 120);
            txtCantidad.Name = "txtCantidad";
            txtCantidad.Size = new Size(95, 23);
            txtCantidad.TabIndex = 8;
            // 
            // btnAgregar
            // 
            btnAgregar.BackColor = Color.Chartreuse;
            btnAgregar.Font = new Font("Arial", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            btnAgregar.Location = new Point(521, 145);
            btnAgregar.Name = "btnAgregar";
            btnAgregar.Size = new Size(40, 40);
            btnAgregar.TabIndex = 9;
            btnAgregar.Text = "+";
            btnAgregar.UseVisualStyleBackColor = false;
            btnAgregar.Click += btnAgregar_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Arial", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(590, 119);
            label5.Name = "label5";
            label5.Size = new Size(60, 24);
            label5.TabIndex = 10;
            label5.Text = "Total:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Arial", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(567, 143);
            label6.Name = "label6";
            label6.Size = new Size(22, 24);
            label6.TabIndex = 11;
            label6.Text = "$";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(0, 0);
            label7.Name = "label7";
            label7.Size = new Size(38, 15);
            label7.TabIndex = 12;
            label7.Text = "label7";
            // 
            // lblTotal
            // 
            lblTotal.AutoSize = true;
            lblTotal.Font = new Font("Arial", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            lblTotal.Location = new Point(595, 145);
            lblTotal.Name = "lblTotal";
            lblTotal.Size = new Size(22, 24);
            lblTotal.TabIndex = 13;
            lblTotal.Text = "0";
            // 
            // button1
            // 
            button1.Location = new Point(713, 133);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 14;
            button1.Text = "Comprar";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // btnCancelar
            // 
            btnCancelar.Location = new Point(713, 162);
            btnCancelar.Name = "btnCancelar";
            btnCancelar.Size = new Size(75, 23);
            btnCancelar.TabIndex = 15;
            btnCancelar.Text = "Cancelar";
            btnCancelar.UseVisualStyleBackColor = true;
            btnCancelar.Click += btnCancelar_Click;
            // 
            // CFrmRealizaCompra
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnCancelar);
            Controls.Add(button1);
            Controls.Add(lblTotal);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(btnAgregar);
            Controls.Add(txtCantidad);
            Controls.Add(label4);
            Controls.Add(txtPrecio);
            Controls.Add(txtProducto);
            Controls.Add(txtIdProveedor);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(dtgRealizaVenta);
            Name = "CFrmRealizaCompra";
            Text = "CFrmRealizaCompra";
            Load += CFrmRealizaCompra_Load;
            ((System.ComponentModel.ISupportInitialize)dtgRealizaVenta).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dtgRealizaVenta;
        private Label label1;
        private Label label2;
        private Label label3;
        private ComboBox txtIdProveedor;
        private TextBox txtProducto;
        private TextBox txtPrecio;
        private Label label4;
        private TextBox txtCantidad;
        private Button btnAgregar;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label lblTotal;
        private Button button1;
        private DataGridViewTextBoxColumn Descripcion;
        private DataGridViewTextBoxColumn Precio;
        private DataGridViewTextBoxColumn Cantidad;
        private DataGridViewTextBoxColumn Subtotal;
        private DataGridViewButtonColumn Eliminar;
        private Button btnCancelar;
    }
}