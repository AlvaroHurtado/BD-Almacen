﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConexionAlmacen
{
    public partial class CFrmRealizaCompra : Form
    {
        public CFrmRealizaCompra()
        {
            InitializeComponent();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CFrmRealizaCompra_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //using (Models.AbarrotesEntities db = new Models.AbarrotesEntities())
            //{
            //    using (var dbContextTransaccion = db.Database.BeginTransaction())
            //    {
            //        try
            //        {
            //            Models.Compras compras = new Models.Compras();
            //            compras.fecha = DateTime.Now;
            //            compras.id_Proveedor = (int)txtIdProveedor.SelectedValue;
            //            compras.total = decimal.Parse(lblTotal.Text.ToString());

            //            db.Compras.Add(compras);
            //            db.SaveChanges();

            //            foreach (DataGridViewRow dr in dtgRealizaVenta.Rows)
            //            {
            //                Models.Detalles_Compras detalles_Compras = new Models.Detalles_Compras();
            //                detalles_Compras.cantidad = int.Parse(dr.Cells[2].Value.ToString());
            //                detalles_Compras.producto = dr.Cells[0].Value.ToString();
            //                detalles_Compras.precio = decimal.Parse(dr.Cells[1].Value.ToString());
            //                detalles_Compras.subtotal = decimal.Parse(dr.Cells[3].Value.ToString());
            //                detalles_Compras.id_Compra = compras.id_Compra;
            //                db.Detalles_Compras.Add(detalles_Compras);
            //                db.SaveChanges();
            //            }

            //            dbContextTransaccion.Commit();
            //            this.Close();
            //        }
            //        catch (Exception ex)
            //        {
            //            dbContextTransaccion.Rollback();
            //        }
            //    }
            //}
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            string producto = txtProducto.Text.Trim();
            string precio = txtPrecio.Text.Trim();
            string cantidad = txtCantidad.Text.Trim();
            string subtotal = (Decimal.Parse(cantidad) * Decimal.Parse(precio)).ToString();

            dtgRealizaVenta.Rows.Add(new object[] { producto, precio, cantidad, subtotal, "Eliminar" });

            txtProducto.Text = "";
            txtPrecio.Text = "";
            txtCantidad.Text = "";
            txtProducto.Focus();

            CalculaTotal();
        }

        private void dtgRealizaVenta_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex != dtgRealizaVenta.Columns["Eliminar"].Index)
                return;

            dtgRealizaVenta.Rows.RemoveAt(e.RowIndex);
            CalculaTotal();
        }

        private void CalculaTotal()
        {
            decimal total = 0;
            foreach (DataGridViewRow dr in dtgRealizaVenta.Rows)
            {
                decimal importe = decimal.Parse(dr.Cells[3].Value.ToString());
                total += importe;
            }

            //int idSeleccionado = (int)txtIdProveedor.SelectedValue;

            lblTotal.Text = total.ToString();
            //lblId.Text = idSeleccionado.ToString();
        }
    }
}
