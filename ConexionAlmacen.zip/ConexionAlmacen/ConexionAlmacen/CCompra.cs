﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ConexionAlmacen
{
    public partial class CCompra : Form
    {

       CConexionAlmacen conexion = new CConexionAlmacen();

        public CCompra()
        {
            InitializeComponent();
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            CMenu pantalla = new CMenu();
            pantalla.Show();
            this.Close();
        }

        private void btnNuevaCompra_Click(object sender, EventArgs e)
        {
            CFrmRealizaCompra cFrmRealizaCompra = new CFrmRealizaCompra();
            cFrmRealizaCompra.ShowDialog();
            MostrarCompras();
        }

        private void CCompra_Load(object sender, EventArgs e)
        {
            MostrarCompras();
        }

        private void MostrarCompras()
        {
            conexion.Abrir();
            SqlCommand mostrarCompras = new SqlCommand("SP_VerCompras", conexion.conectarBaseDatos);
            mostrarCompras.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();
            dt.Load(mostrarCompras.ExecuteReader());
            this.dtgCompra.DataSource = dt;
            conexion.Cerrar();
        }
    }
}
