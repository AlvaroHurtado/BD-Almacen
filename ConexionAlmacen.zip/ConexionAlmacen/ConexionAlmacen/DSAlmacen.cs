﻿namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}

namespace ConexionAlmacen
{
}
namespace ConexionAlmacen.DSAlmacenTableAdapters {
    
    
    public partial class EmpleadosTableAdapter {
    }
}
