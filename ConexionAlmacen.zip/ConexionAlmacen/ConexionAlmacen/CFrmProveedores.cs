﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConexionAlmacen
{
    public partial class CFrmProveedores : Form
    {
        private int? Id;

        public CFrmProveedores(int? pId = null)
        {
            InitializeComponent();
            this.Id = pId;
        }

        private void txtNombres_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void CFrmProveedores_Load(object sender, EventArgs e)
        {
            if (Id != null)
            {
                DSAlmacenTableAdapters.ProveedoresTableAdapter ta = new DSAlmacenTableAdapters.ProveedoresTableAdapter();
                DSAlmacen.ProveedoresDataTable dt = ta.ObtenerProveedores((int)Id);
                DSAlmacen.ProveedoresRow row = (DSAlmacen.ProveedoresRow)dt.Rows[0];
                txtCompania.Text = row.compania;
                txtNombres.Text = row.nombresContacto;
                txtApellidoP.Text = row.apellidoPaterno;
                txtApellidoM.Text = row.apellidoMaterno;
                txtTelefono.Text = row.telefono;
                txtTelefonoC.Text = row.telefonoCompania;
            }
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            DSAlmacenTableAdapters.ProveedoresTableAdapter ta = new DSAlmacenTableAdapters.ProveedoresTableAdapter();

            if (Id == null)
            {
                ta.AgregarProveedor(txtCompania.Text,  txtNombres.Text, txtApellidoP.Text, txtApellidoM.Text, txtTelefono.Text, txtTelefonoC.Text);
            }
            else
            {
                ta.ActualizarProveedor((int)Id, txtCompania.Text, txtNombres.Text, txtApellidoP.Text, txtApellidoM.Text, txtTelefono.Text, txtTelefonoC.Text);
            }
            this.Close();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
